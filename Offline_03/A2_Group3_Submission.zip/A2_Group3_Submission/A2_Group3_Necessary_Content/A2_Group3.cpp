#include <iostream>
#include <fstream>

using namespace std;

string reg_to_hex(string reg){
    if(reg == "$zero"){
        return "0";
    }
    else if(reg == "$t0"){
        return "1";
    }
    else if(reg == "$t1"){
        return "2";
    }
    else if(reg == "$t2"){
        return "3";
    }
    else if(reg == "$t3"){
        return "4";
    }
    else if(reg == "$t4"){
        return "5";
    }
}

string ins_to_hex(string ins){
    if(ins == "add"){
        return "f";
    }
    else if(ins == "addi"){
        return "5";
    }
    else if(ins == "sub"){
        return "7";
    }
    else if(ins == "subi"){
        return "c";
    }
    else if(ins == "and"){
        return "e";
    }
    else if(ins == "andi"){
        return "4";
    }
    else if(ins == "or"){
        return "b";
    }
    else if(ins == "ori"){
        return "6";
    }
    else if(ins == "sll"){
        return "d";
    }
    else if(ins == "srl"){
        return "2";
    }
    else if(ins == "nor"){
        return "a";
    }
    else if(ins == "lw"){
        return "8";
    }
    else if(ins == "sw"){
        return "0";
    }
    else if(ins == "beq"){
        return "3";
    }
    else if(ins == "bneq"){
        return "1";
    }
    else if(ins == "j"){
        return "9";
    }

}

string addr_to_hex(string addr){
    string new_addr = "";
    if(addr[0] != '-'){
        cout << addr << endl << endl;
        char hex_addr[addr.length() + 1];
        int i = atoi(addr.c_str());
        sprintf(hex_addr, "%x", i);
        cout << hex_addr << endl << endl;
        return hex_addr;
    }
    else{
        cout << addr << endl << endl << endl;
        for(int i = 1; i <= addr.length(); i++){
            new_addr += addr[i];
        }
        cout << new_addr << endl << endl << endl;
        char hex_addr[new_addr.length() + 1];
        int i = atoi(new_addr.c_str());
        sprintf(hex_addr, "%x", 16-i);

        return hex_addr;
    }
}

int main(){
    ifstream input("input.txt");
    ofstream output("out.txt");
    ofstream mid("mid.txt");

    string str;
    string ins;
    string src1;
    string src2;
    string des;
    string addr;
    string instruction;
    string labels[10][4];
    int label_index = 0;
    for(int i = 0; i < 10; i++){
        labels[i][1] = "";
    }

    int i;
    int c = 0;
    int line_count = 0;

    while(getline(input, str)){
        ins = "";
        src1 = "";
        src2 = "";
        des = "";
        addr = "";
        instruction = "";
        string label = "";
        c = 0;
        cout << str << endl;
        for(i = 0; i < str.length(); i++){
            if(str[i] == ',' || str[i] == ';' || str[i] == '(' || str[i] == ')' || str[i] == ':'){
                if((str[i] == ':') && (i == (str.length() - 1))){
                    for(int a = 0; a < 10; a++){
                        if(labels[a][1] == ins){
                            string end_pos = to_string(line_count);
                            labels[a][3] = end_pos;
                        }
                    }
                }
                continue;
            }

            if(str[i] == ' '){
                int check = 0;
                if(c == 0){
                    if(ins == "add" || ins == "sub" || ins == "and" || ins == "or" || ins == "nor" || ins == "addi" || ins == "subi" || ins == "andi" || ins == "ori" || ins == "sll" || ins == "srl" ||ins == "beq" || ins == "bneq" || ins == "lw" || ins == "sw" || ins == "j"){
                        c++;
                    }
                    else{
                        int label_check;
                        for(label_check = 0; label_check < 10; label_check++){
                            if(labels[label_check][1] == ins){
                                string end_pos = to_string(line_count);
                                //sprintf(end_pos, "%d", line_count);
                                labels[label_check][3] = end_pos;
                                ins = "";
                                //break;
                                check = 1;
                            }
                        }

                        if(check == 0){
                            labels[label_index][1] = ins;
                            string end_pos = to_string(line_count);
                            labels[label_index][3] = end_pos;
                            label_index++;
                            ins = "";

                        }
                    }

                    continue;
                }
                else{
                    c++;
                    continue;
                }

            }
            if(c == 0){
                ins += str[i];

            }

            else if(c == 1){
                int done = 0;
                if(ins == "j"){
                    label += str[i];

                    if(i == str.length() - 1){
                        for(int a = 0; a < 10; a++){
                            if(labels[a][1] == label){
                                if(labels[a][0] != "jump"){
                                    labels[a][0] = "jump";
                                    string start_pos = to_string(line_count);
                                    labels[a][2] = start_pos;
                                    done = 1;
                                }
                            }
                        }
                        if(done == 0){
                            labels[label_index][0] = "jump";
                            labels[label_index][1] = label;
                            string start_pos = to_string(line_count);
                            labels[label_index][2] = start_pos;
                            label_index++;
                        }
                    }
                }

            }

            else if(c == 3){
                int done = 0;
                if(ins == "beq" || ins == "bneq"){
                    label += str[i];

                    if(i == (str.length() - 1)){
                        for(int a = 0; a < 10; a++){
                            if(labels[a][1] == label){
                                if(labels[a][0] != "branch"){
                                    labels[a][0] = "branch";
                                    string start_pos = to_string(line_count);
                                    labels[a][2] = start_pos;
                                    done = 1;
                                }
                            }
                        }
                        if(done == 0){
                            labels[label_index][0] = "branch";
                            labels[label_index][1] = label;
                            string start_pos = to_string(line_count);
                            labels[label_index][2] = start_pos;
                            label_index++;
                        }
                    }

                }
            }

        }
        line_count++;
    }
    for(int i = 0; i < label_index; i++){
        cout << i << "  " << labels[i][0] << "  " << labels[i][1] << "  " << labels[i][2] << "  " << labels[i][3] << endl;
    }
    line_count = 0;
    input.close();
    input.open("input.txt");
    while(getline(input, str)){
        ins = "";
        src1 = "";
        src2 = "";
        des = "";
        addr = "";
        instruction = "";
        c = 0;
        cout << str << endl;
        for(i = 0; i < str.length(); i++){
            if(str[i] == ',' || str[i] == ';' || str[i] == '(' || str[i] == ')' || str[i] == ':'){
                continue;
            }
            if(str[i] == ' '){
                if(c == 0){
                    if(ins == "add" || ins == "sub" || ins == "and" || ins == "or" || ins == "nor" || ins == "addi" || ins == "subi" || ins == "andi" || ins == "ori" || ins == "sll" || ins == "srl" ||ins == "beq" || ins == "bneq" || ins == "lw" || ins == "sw" || ins == "j"){
                        c++;
                    }
                    else{
                        ins = "";
                    }
                }
                else{
                    c++;
                }
                continue;

            }
            if(c == 0){
                ins += str[i];
            }

            else if(c == 1){
                if(ins == "sw"){
                    src2 += str[i];
                }
                else if(ins == "j"){
                    addr += str[i];
                }
                else if(ins == "beq" || ins == "bneq"){
                    src1 += str[i];
                }
                else{
                    des += str[i];
                }
            }
            else if(c == 2){
                if(ins == "lw" || ins == "sw"){
                    addr += str[i];
                    c++;
                }
                else if(ins == "beq" || ins == "bneq"){
                    src2 += str[i];
                }
                else{
                    src1 += str[i];
                }
            }
            else if(c == 3){
                if(ins == "lw" || ins == "sw"){
                    src1 += str[i];
                }
                else if(ins == "addi" || ins == "subi" || ins == "andi" || ins == "ori" || ins == "sll" || ins == "srl" || ins == "beq" || ins == "bneq"){
                    addr += str[i];
                }
                else{
                    src2 += str[i];
                }
            }

        }
        //cout << i << endl;
        cout << "ins: " + ins << " src1: " << src1 << " src2: " << src2 << " des: " << des << " addr: " << addr << endl;

        if(ins == "j"){
            for(int i = 0; i < label_index; i++){
                if(labels[i][1] == addr){
                    addr = addr_to_hex(labels[i][3]);
                }
            }
            instruction = ins_to_hex(ins) + addr + "0";
        }
        else if(ins == "end"){
            instruction = "0000";
        }
        else if(ins == "lw"){
            instruction = ins_to_hex(ins) + reg_to_hex(src1) + reg_to_hex(des) + addr_to_hex(addr);
        }
        else if(ins == "sw"){
            instruction = ins_to_hex(ins) + reg_to_hex(src1) + reg_to_hex(src2) + addr_to_hex(addr);
        }
        else if(ins == "beq" || ins == "bneq"){
            for(int i = 0; i < label_index; i++){
                if(labels[i][1] == addr){
                    int start = stoi(labels[i][2]);
                    int dest = stoi(labels[i][3]);
                    int def = dest - start - 1;
                    addr = to_string(def);
                }
            }
            instruction = ins_to_hex(ins) + reg_to_hex(src1) + reg_to_hex(src2) + addr_to_hex(addr);
        }
        else if(ins == "add" || ins == "sub" || ins == "and" || ins == "or" || ins == "nor"){
            instruction = ins_to_hex(ins) + reg_to_hex(src1) + reg_to_hex(src2) + reg_to_hex(des);
        }
        else{
            instruction = ins_to_hex(ins) + reg_to_hex(src1) + reg_to_hex(des) + addr_to_hex(addr);
        }
        cout << instruction << endl;
        output << instruction << endl;
        line_count++;

    }
}
