/*
 * Instruction.cpp
 *
 * Created: 2/15/2023 3:07:25 PM
 * Author : AJOY DEY
 */ 

/*
 *
 */ 

#define F_CPU 1000000UL
#include <avr/io.h>
#include <util/delay.h>
/*
MOJNFBHCLPKGDIEA
/*i-type opcode, src, dst, val... addi $t1, $zero, 3*/ 
/*i-type opcode, src, dst, val... subi $t2, $zero, -2*/
/*r-type opcode, src1, src2, dst....add $t0, $t1, $t2 */
/*r-type opcode, src1, src2, dst...sub $t3, $t1, $t2*/
/*r-type opcode, src1, src2, dst...sub $t1, $t3, $t0*/

uint16_t INSTRUCTIONS[1<<8] = {
	 0x5023 
	,0xc03e 
	
};

int main(void)
{
	// Some pins of PORTC can not be used for I/O directly.
	// turn of JTAG to use them
	// o write a 1 to the JTD bit twice consecutively to turn it off
	MCUCSR = (1<<JTD);  MCUCSR = (1<<JTD);
	
    DDRA = 0x00;	// input pc
	
	// Instruction : D[7:0]C[7:0]
	DDRC = 0xFF;	// lower 8-bits of instruction
	DDRD = 0xFF;	// upper 8-bits of instruction
	
	uint8_t pc = -1;
	uint16_t instruction;
	/* Replace with your application code */
    while (1) 
    {
		if (PINA != pc) {
			pc = PINA;
			instruction = INSTRUCTIONS[pc];
			PORTC = (uint8_t) instruction;
			PORTD = (uint8_t) (instruction >> 8);
			_delay_ms(1000);
		}
    }
}


